const details = {
  plastic: {
    title: "Plastic Waste in the Ocean",
    image: "https://images.unsplash.com/photo-1621451537084-482c73073a0f?auto=format&fit=crop&w=1400&q=85",
    alt: "Plastic waste floating in water",
    cause: "Plastic pollution happens when plastic rubbish is not disposed of properly. Bags, bottles, food wrappers and other items can be carried by wind, drains and rivers into the ocean. Some plastic also comes from activities at sea.",
    effect: "Plastic can remain in the environment for a very long time. Sea turtles may mistake floating plastic bags for food, while seabirds and fish can swallow small plastic pieces. Larger pieces can also trap animals. Tiny pieces, called microplastics, can spread through marine environments and enter food chains.",
    tip: "What you can do: carry a reusable water bottle and shopping bag, avoid unnecessary single-use packaging, and always put rubbish in a bin."
  },
  chemicals: {
    title: "Chemical and Wastewater Pollution",
    image: "https://images.unsplash.com/photo-1581244277943-fe4a9c777189?auto=format&fit=crop&w=1400&q=85",
    alt: "Wastewater flowing through a drainage channel",
    cause: "Wastewater from homes, farms and factories may contain detergents, oils, chemicals, fertilisers or other pollutants. If it is not properly treated, it can flow into rivers and eventually reach the sea.",
    effect: "Some chemicals can poison marine organisms or build up in the environment. Too much fertiliser can cause rapid growth of algae. When the algae die and decompose, oxygen in the water can decrease, making it difficult for fish and other animals to survive.",
    tip: "What you can do: never pour paint, motor oil or chemicals into drains. Follow local instructions for disposing of household chemicals safely."
  },
  fishing: {
    title: "Lost or Abandoned Fishing Gear",
    image: "https://images.unsplash.com/photo-1518467166778-b88f373ffec7?auto=format&fit=crop&w=1400&q=85",
    alt: "Fishing nets and ropes",
    cause: "Fishing nets, lines, ropes and traps can be lost, damaged or abandoned at sea. This equipment may continue floating or resting underwater after people stop using it.",
    effect: "Lost fishing gear can keep catching animals. Turtles, fish, seabirds and marine mammals may become trapped or injured. Nets can also damage coral reefs and other underwater habitats.",
    tip: "What you can do: support responsible fishing practices and never leave fishing line, hooks or rubbish behind when visiting the coast."
  },
  oil: {
    title: "Oil Pollution",
    image: "https://images.unsplash.com/photo-1516937941344-00b4e0337589?auto=format&fit=crop&w=1400&q=85",
    alt: "Industrial ships and marine activity",
    cause: "Oil can enter the ocean through accidents involving ships or offshore facilities, leaks, and improper disposal. Even smaller amounts of oil can pollute water and shorelines.",
    effect: "Oil can coat the feathers of seabirds and the fur of some marine mammals, making it harder for them to stay warm or move normally. Oil can also affect fish, shellfish, coastal plants and habitats.",
    tip: "What you can do: never pour used cooking oil or motor oil into drains. Take used oil to an approved collection or recycling point."
  },
  reusables: {
    title: "Use Reusable Items",
    image: "https://images.unsplash.com/photo-1602143407151-7111542de6e8?auto=format&fit=crop&w=1400&q=85",
    alt: "Reusable drinking water bottle",
    cause: "Many everyday products are designed to be used once and then thrown away. Single-use plastic bottles, cups, bags and cutlery can become litter if they are not managed properly.",
    effect: "Choosing reusable items helps reduce the amount of waste that needs to be collected and managed. This lowers the chance of plastic litter reaching rivers, beaches and the ocean.",
    tip: "Try this: bring a refillable bottle, use a lunchbox, and keep a reusable shopping bag with you. Wash and reuse items safely."
  },
  recycle: {
    title: "Reduce, Reuse and Recycle",
    image: "https://images.unsplash.com/photo-1532996122724-e3c354a0b15?auto=format&fit=crop&w=1400&q=85",
    alt: "Recycling bins for sorting waste",
    cause: "Rubbish can reach the sea when it is dropped outdoors, blown away from uncovered bins or carried by rainwater into drains and rivers.",
    effect: "Reducing waste means fewer materials can become litter. Reusing and recycling suitable items can save resources and help keep rubbish out of natural habitats. Remember that recycling rules differ by location.",
    tip: "Try this: separate recyclable items according to your local recycling rules, keep rubbish in a covered bin and choose products with less packaging."
  },
  cleanup: {
    title: "Join Beach and River Clean-ups",
    image: "https://images.unsplash.com/photo-1618477461853-cf6ed80faba5?auto=format&fit=crop&w=1400&q=85",
    alt: "Volunteers helping to clean a beach",
    cause: "Litter left on beaches and riverbanks can be washed into the ocean by rain, wind and waves. Clean-up activities help remove some of this rubbish from the environment.",
    effect: "Removing litter can make shorelines safer for wildlife and people. Clean-ups also help communities see which types of rubbish are common and encourage better waste habits.",
    tip: "Try this: join an organised clean-up with your school, family or community. Follow the organiser's safety instructions and do not touch sharp, chemical or unknown waste."
  },
  seafood: {
    title: "Choose Sustainable Seafood",
    image: "https://images.unsplash.com/photo-1510130387422-82bed34b37e9?auto=format&fit=crop&w=1400&q=85",
    alt: "Fresh fish at a seafood market",
    cause: "Overfishing happens when fish are caught faster than their populations can reproduce. Destructive fishing methods can also damage habitats and accidentally catch other species.",
    effect: "Unsustainable fishing can reduce fish populations, disturb food webs and affect the people who depend on the sea for food and work. Responsible fishing helps allow marine populations to recover.",
    tip: "Try this: when seafood information is available, ask where it came from and choose products recommended by trusted local sustainability guides."
  },
  awareness: {
    title: "Spread Awareness",
    image: "https://images.unsplash.com/photo-1531058020387-3be344556be6?auto=format&fit=crop&w=1400&q=85",
    alt: "Community environmental awareness event",
    cause: "Some people may not realise that litter on streets, in drains or beside rivers can eventually reach the ocean. Others may not know how pollution affects marine animals.",
    effect: "Sharing accurate information can help people understand the problem and make better everyday choices. Schools and communities can work together to reduce waste and protect local waterways.",
    tip: "Try this: make a school poster, give a short presentation, share reliable facts and encourage friends to use less plastic."
  },
  water: {
    title: "Keep Drains and Rivers Clean",
    image: "https://images.unsplash.com/photo-1437482078695-73f5ca6c96e2?auto=format&fit=crop&w=1400&q=85",
    alt: "Clean flowing river surrounded by nature",
    cause: "Storm drains carry rainwater from streets towards streams and rivers. Rubbish, oil and chemicals left on roads or poured into drains can be carried into waterways and then to the sea.",
    effect: "Pollution in rivers can harm freshwater animals first and then affect coastal and marine environments. Keeping waterways clean helps protect connected ecosystems from the land to the ocean.",
    tip: "Try this: put litter in bins, do not pour chemicals or oil into drains, and tell a trusted adult or local authority if you notice serious pollution."
  }
};

function openDetail(key) {
  const item = details[key];
  if (!item) return;
  document.getElementById("detailTitle").textContent = item.title;
  const img = document.getElementById("detailImage");
  img.src = item.image;
  img.alt = item.alt;
  document.getElementById("detailText").innerHTML =
    "<h3>How does this happen?</h3><p>" + item.cause + "</p>" +
    "<h3>What are the effects?</h3><p>" + item.effect + "</p>";
  document.getElementById("detailTip").textContent = item.tip;
  document.getElementById("detailScreen").classList.add("active");
  document.getElementById("detailScreen").scrollTop = 0;
  document.body.style.overflow = "hidden";
}
function closeDetail() {
  document.getElementById("detailScreen").classList.remove("active");
  document.body.style.overflow = "";
}
function checkAnswer(answer) {
  const result = document.getElementById("result");
  if (answer === "B") {
    result.textContent = "Correct! Reusable bottles help reduce plastic waste. 🌟";
    result.style.color = "#087443";
  } else {
    result.textContent = "Not quite. Try again! Think about how to reduce plastic waste. 🌊";
    result.style.color = "#a33b24";
  }
}
document.addEventListener("keydown", function(event) {
  if (event.key === "Escape") closeDetail();
});
